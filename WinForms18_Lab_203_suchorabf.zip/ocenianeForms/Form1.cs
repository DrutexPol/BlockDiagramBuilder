﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ocenianeForms
{
    public partial class Form1 : Form
    {
        private int Xsize = 110;
        private int Ysize = 80;
        private int currentBlock = 0;
        private Bitmap drawArea;
        private Pen pen;
        private List<Shape> shapes = new List<Shape>();

        public Form1()
        {
            InitializeComponent();
            drawArea = new Bitmap(Screen.PrimaryScreen.WorkingArea.Width, Screen.PrimaryScreen.WorkingArea.Height);
            pictureBox1.Image = drawArea;
            pen = new Pen(Brushes.Black, 2);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            currentBlock = 1;
            button4.BackColor = Color.Aqua;
            button5.BackColor = SystemColors.ButtonFace;
        }

        private void button6_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            currentBlock = 2;
            button4.BackColor = SystemColors.ButtonFace;
            button5.BackColor = Color.Aqua;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                using (Graphics g = Graphics.FromImage(drawArea))
                {
                    Shape shape = null;
                    if (currentBlock == 1)
                    {
                        shape = new MyRect(e.X, e.Y, "blok decyzyjny");
                    }
                    else if (currentBlock == 2)
                    {
                        shape = new MyRomb(e.X,e.Y, "blok decyzyjny");
                    }
                    else return;
                    shape.rectangle = new Rectangle(e.X - Xsize / 2, e.Y - Ysize / 2, Xsize, Ysize);
                    g.FillPolygon(Brushes.White, shape.points);
                    g.DrawPolygon(pen, shape.points);
                    StringFormat stringFormat = new StringFormat();
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;
                    g.DrawString(shape.text, SystemFonts.DefaultFont, Brushes.Black, shape.rectangle, stringFormat);
                    shapes.Add(shape);
                }
            }

            pictureBox1.Refresh();
        }
    }
}