﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ocenianeForms
{
    class MyRect : Shape
    {
        public MyRect(int x, int y, string text) : base()
        {
            points = new PointF[]
            {
                new PointF(x - Xsize / 2, y - Ysize / 2),
                new PointF(x - Xsize / 2, y + Ysize / 2),
                new PointF(x + Xsize / 2, y + Ysize / 2),
                new PointF(x + Xsize / 2, y - Ysize / 2)
            };
            this.text = text;
        }
    }
}
