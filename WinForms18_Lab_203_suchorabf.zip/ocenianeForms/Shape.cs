﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ocenianeForms
{
    class Shape
    {
        protected int Xsize = 110;
        protected int Ysize = 80;
        public PointF[] points;
        public String text { set; get; }
        public Rectangle rectangle { set; get; }
    public Shape()
        {
        }
    }
}
